# Ngamding
Ngamding (Ngampus Ngoding) adalah projek saya dari awal kuliah hingga semester akhir dimana saya berniat untuk membuat web ini dari awal saya masuk kuliah hingga selesai dengan isi web biodata saya dan apa yang saya dapat selama kuliah di UNSA
